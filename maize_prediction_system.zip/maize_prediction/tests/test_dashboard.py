import json

from app.main import dashboard


def test_dashboard_serves_homepage_and_forecast_controls() -> None:
    client = dashboard.server.test_client()

    homepage = client.get("/")
    layout = client.get("/_dash-layout")

    assert homepage.status_code == 200
    assert "MAIZE PREDICTION SYSTEM FOR KENYA" in homepage.get_data(as_text=True)
    assert layout.status_code == 200
    layout_content = json.dumps(layout.get_json())
    assert "forecast-button" in layout_content
    assert "forecast-chart" in layout_content
    assert "county-filter" in layout_content
