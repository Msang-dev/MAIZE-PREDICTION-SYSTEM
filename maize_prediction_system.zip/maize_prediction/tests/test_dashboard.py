import json

import pytest

from app.dashboard import (
    _create_forecast_figure,
    _forecast_csv,
    _forecast_table_rows,
    _ranked_county_cards,
)
from app.main import dashboard


def test_dashboard_serves_homepage_and_forecast_controls() -> None:
    client = dashboard.server.test_client()

    homepage = client.get("/")
    layout = client.get("/_dash-layout")

    assert homepage.status_code == 200
    assert "MAIZE PREDICTION SYSTEM FOR KENYA" in homepage.get_data(as_text=True)
    assert layout.status_code == 200
    layout_content = json.dumps(layout.get_json())
    assert "forecast-button" in layout_content
    assert "forecast-chart" in layout_content
    assert "county-filter" in layout_content
    assert "chart-mode" in layout_content
    assert "download-button" in layout_content
    assert client.get("/assets/dashboard.css").status_code == 200


def sample_predictions() -> list[dict[str, float | str]]:
    return [
        {
            "county": county,
            "production_tonnes": production,
            "lower_90_tonnes": production - 100,
            "upper_90_tonnes": production + 100,
        }
        for county, production in (
            ("Mombasa", 100.0),
            ("Kwale", 500.0),
            ("Kilifi", 300.0),
            ("Tana River", 200.0),
        )
    ]


def test_ranked_chart_respects_count_and_estimate_range_toggle() -> None:
    predictions = sample_predictions()

    chart = _create_forecast_figure(predictions, "ranked", 2, False)

    assert list(chart.data[0].y) == ["Kilifi", "Kwale"]
    assert chart.data[0].error_x.visible is False
    assert chart.data[0].error_x.array == pytest.approx([100, 100])
    assert [row["county"] for row in _forecast_table_rows(predictions)] == [
        "Kwale",
        "Kilifi",
        "Tana River",
        "Mombasa",
    ]


def test_share_chart_keeps_other_counties_in_share_denominator() -> None:
    chart = _create_forecast_figure(sample_predictions(), "share", 2, True)

    assert list(chart.data[0].labels) == ["Kwale", "Kilifi", "Other counties"]
    assert list(chart.data[0].values) == pytest.approx([500, 300, 300])


def test_leading_county_cards_are_ranked_and_show_total_share() -> None:
    cards = _ranked_county_cards(sample_predictions(), 1100)

    assert len(cards) == 4
    assert cards[0].children[0].children[1].children == "Kwale"
    assert cards[0].children[1].children[1].children == "45.5%"


def test_forecast_csv_includes_year_and_all_estimate_columns() -> None:
    rows = _forecast_table_rows(sample_predictions())

    csv_content = _forecast_csv(rows[:1], 2025).splitlines()

    assert csv_content[0] == (
        "rank,county,year,production_tonnes,lower_90_tonnes,upper_90_tonnes"
    )
    assert csv_content[1] == "1,Kwale,2025,500.0,400.0,600.0"
