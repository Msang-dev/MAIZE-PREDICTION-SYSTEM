import io

import pandas as pd

from app.data_import import read_history
from app.model import COUNTIES


def test_reads_tidy_excel_sheet_and_normalizes_county_names() -> None:
    rows = []
    aliases = {
        "Homa Bay": "Homabay",
        "Tharaka-Nithi": "Tharaka-Nthi",
        "Elgeyo-Marakwet": "Elgeyo/Marakwet",
        "Taita-Taveta": "Taita/Taveta",
    }
    for index, county in enumerate(COUNTIES):
        source_county = aliases.get(county, county)
        if county == "Nairobi":
            source_county += " "
        rows.extend(
            [
                {
                    "County": source_county,
                    "Year": 2020,
                    "Indicator": "Production (MT)",
                    "Value": 100 + index,
                },
                {
                    "County": source_county,
                    "Year": 2020,
                    "Indicator": "Area (HA)",
                    "Value": 20 + index,
                },
                {
                    "County": source_county,
                    "Year": 2020,
                    "Indicator": "Yield(MT/HA)",
                    "Value": 5 + index,
                },
            ]
        )
    workbook = io.BytesIO()
    with pd.ExcelWriter(workbook, engine="openpyxl") as writer:
        pd.DataFrame(rows).to_excel(writer, sheet_name="Tidy data", index=False)
    history = read_history("history.xlsx", workbook.getvalue())

    assert len(history) == 47
    assert set(history["county"]) == set(COUNTIES)
    assert set(history.columns) == {
        "county",
        "year",
        "production_tonnes",
        "area_ha",
        "yield_tonnes_per_ha",
    }
    assert history["production_tonnes"].sum() > 0


def test_reads_csv_training_data() -> None:
    csv = b"county,year,production_tonnes\nMombasa,2020,42\n"

    history = read_history("history.csv", csv)

    assert history.to_dict("records") == [
        {"county": "Mombasa", "year": 2020, "production_tonnes": 42}
    ]


def test_reads_wide_excel_with_year_in_indicator_headers() -> None:
    workbook = io.BytesIO()
    with pd.ExcelWriter(workbook, engine="openpyxl") as writer:
        pd.DataFrame(
            [
                {
                    "County": "Homa Bay",
                    "2020 Production (MT)": 120,
                    "2020 Area (HA)": 30,
                    "2020 Yield (MT/HA)": 4,
                }
            ]
        ).to_excel(writer, sheet_name="Annual", index=False)

    history = read_history("history.xlsx", workbook.getvalue())

    assert history.to_dict("records") == [
        {
            "county": "Homa Bay",
            "year": 2020,
            "production_tonnes": 120,
            "area_ha": 30,
            "yield_tonnes_per_ha": 4,
        }
    ]
