import asyncio

import pandas as pd
import pytest
from fastapi import HTTPException

from app.main import train
from app.model import COUNTIES, DatasetError, predict_counties, train_model, validate_history


def sample_history() -> pd.DataFrame:
    rows = []
    for county_index, county in enumerate(COUNTIES):
        for year in range(2019, 2024):
            rows.append(
                {
                    "county": county,
                    "year": year,
                    "production_tonnes": 1000 + county_index * 10 + (year - 2019) * 25,
                    "area_ha": 500 + county_index + (year - 2019) * 3,
                }
            )
    return pd.DataFrame(rows)


def test_training_backtests_and_forecasts_all_47_counties() -> None:
    bundle = train_model(sample_history())
    scenarios = [
        {"county": county} for county in COUNTIES
    ]

    predictions = predict_counties(bundle, 2024, scenarios)

    assert len(predictions) == 47
    assert {row["county"] for row in predictions} == set(COUNTIES)
    assert all(row["production_tonnes"] >= 0 for row in predictions)
    assert bundle["metrics"]["backtest_rows"] == 47
    assert bundle["metrics"]["mae_tonnes"] is not None
    assert "three_observation_mean_mae_tonnes" in bundle["metrics"]
    assert "random_forest_mae_tonnes" in bundle["metrics"]
    if bundle["selected_model"] == "three_observation_mean":
        county_history = bundle["history"]
        expected = county_history[
            county_history["county"] == predictions[0]["county"]
        ]["production_tonnes"].tail(3).mean()
        assert predictions[0]["production_tonnes"] == pytest.approx(expected)


def test_validation_rejects_missing_counties() -> None:
    history = sample_history()
    history = history[history["county"] != "Mombasa"]

    with pytest.raises(DatasetError, match="every county"):
        validate_history(history)


def test_prediction_requires_a_scenario_for_every_county() -> None:
    bundle = train_model(sample_history())
    scenarios = [
        {"county": county}
        for county in COUNTIES[:-1]
    ]

    with pytest.raises(DatasetError, match="47 counties"):
        predict_counties(bundle, 2024, scenarios)


def test_prediction_requires_next_historical_year() -> None:
    bundle = train_model(sample_history())
    scenarios = [
        {"county": county}
        for county in COUNTIES
    ]

    with pytest.raises(DatasetError, match="next year"):
        predict_counties(bundle, 2025, scenarios)


def test_prediction_rejects_counties_missing_latest_historical_season() -> None:
    history = sample_history()
    history = history[~((history["county"] == "Mombasa") & (history["year"] == 2023))]
    bundle = train_model(history)
    scenarios = [
        {"county": county} for county in COUNTIES
    ]

    with pytest.raises(DatasetError, match="Mombasa"):
        predict_counties(bundle, 2024, scenarios)


def test_training_endpoint_rejects_missing_admin_token(monkeypatch) -> None:
    monkeypatch.delenv("MAIZE_ADMIN_TOKEN", raising=False)

    with pytest.raises(HTTPException) as error:
        asyncio.run(train(None, None))

    assert error.value.status_code == 503


def test_training_endpoint_rejects_incorrect_admin_token(monkeypatch) -> None:
    monkeypatch.setenv("MAIZE_ADMIN_TOKEN", "a" * 40)

    with pytest.raises(HTTPException) as error:
        asyncio.run(train(None, "Bearer wrong-token"))

    assert error.value.status_code == 401
