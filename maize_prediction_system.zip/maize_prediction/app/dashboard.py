from __future__ import annotations

import csv
import io
from collections.abc import Callable
from typing import Any

import plotly.graph_objects as go
from dash import Dash, Input, Output, State, dash_table, dcc, html, no_update
from fastapi import HTTPException

from app.model import COUNTIES, DatasetError, predict_counties


INK = "#183329"
MUTED = "#718078"
PLOT_LAYOUT = {
    "font": {"family": "Segoe UI, Arial, sans-serif", "color": INK, "size": 12},
    "paper_bgcolor": "rgba(255,255,255,0)",
    "plot_bgcolor": "rgba(255,255,255,0)",
    "margin": {"l": 8, "r": 22, "t": 16, "b": 12},
}


def _short_tonnes(value: float) -> str:
    if abs(value) >= 1_000_000:
        return f"{value / 1_000_000:.2f}M"
    if abs(value) >= 10_000:
        return f"{value / 1_000:.1f}k"
    return f"{value:,.0f}"


def _empty_figure() -> go.Figure:
    figure = go.Figure()
    figure.update_layout(
        **PLOT_LAYOUT,
        height=390,
        xaxis={"visible": False},
        yaxis={"visible": False},
        annotations=[
            {
                "text": "Your county forecast will appear here.",
                "showarrow": False,
                "font": {"color": MUTED, "size": 15},
            }
        ],
    )
    return figure


def _create_forecast_figure(
    predictions: list[dict[str, Any]],
    chart_mode: str,
    top_counties: int,
    show_ranges: bool,
) -> go.Figure:
    ordered = sorted(
        predictions,
        key=lambda prediction: float(prediction["production_tonnes"]),
        reverse=True,
    )
    chart_predictions = ordered[: max(1, min(top_counties, len(ordered)))]
    if chart_mode == "share":
        labels = [str(prediction["county"]) for prediction in chart_predictions]
        values = [
            float(prediction["production_tonnes"])
            for prediction in chart_predictions
        ]
        remaining = ordered[len(chart_predictions) :]
        if remaining:
            labels.append("Other counties")
            values.append(
                sum(float(prediction["production_tonnes"]) for prediction in remaining)
            )
        total_production = sum(float(row["production_tonnes"]) for row in ordered)
        figure = go.Figure(
            data=[
                go.Pie(
                    labels=labels,
                    values=values,
                    hole=0.66,
                    sort=False,
                    marker={
                        "colors": [
                            "#176b46",
                            "#2a875b",
                            "#49a36f",
                            "#72bb87",
                            "#98cda2",
                            "#badbbd",
                            "#d0e7ce",
                            "#e1eee0",
                        ]
                    },
                    textinfo="label+percent",
                    textposition="outside",
                    hovertemplate="%{label}<br>%{value:,.0f} tonnes<br>%{percent}<extra></extra>",
                )
            ]
        )
        figure.update_layout(
            **PLOT_LAYOUT,
            height=440,
            showlegend=False,
            annotations=[
                {
                    "text": (
                        f"{_short_tonnes(total_production)}"
                        "<br><span style='font-size:11px'>TONNES</span>"
                    ),
                    "showarrow": False,
                    "font": {"color": INK, "size": 21},
                }
            ],
        )
        return figure

    chart_predictions = list(reversed(chart_predictions))
    figure = go.Figure(
        data=[
            go.Bar(
                x=[
                    float(prediction["production_tonnes"])
                    for prediction in chart_predictions
                ],
                y=[str(prediction["county"]) for prediction in chart_predictions],
                orientation="h",
                marker={
                    "color": [
                        "#26734d"
                        if index == len(chart_predictions) - 1
                        else "#73a687"
                        for index in range(len(chart_predictions))
                    ],
                    "line": {"width": 0},
                },
                error_x={
                    "type": "data",
                    "symmetric": False,
                    "visible": show_ranges,
                    "array": [
                        max(
                            float(prediction["upper_90_tonnes"])
                            - float(prediction["production_tonnes"]),
                            0,
                        )
                        for prediction in chart_predictions
                    ],
                    "arrayminus": [
                        max(
                            float(prediction["production_tonnes"])
                            - float(prediction["lower_90_tonnes"]),
                            0,
                        )
                        for prediction in chart_predictions
                    ],
                    "color": "#728879",
                    "thickness": 1.5,
                    "width": 3,
                },
                customdata=[
                    [
                        float(prediction["lower_90_tonnes"]),
                        float(prediction["upper_90_tonnes"]),
                    ]
                    for prediction in chart_predictions
                ],
                hovertemplate=(
                    "<b>%{y}</b><br>Estimate: %{x:,.0f} tonnes"
                    "<br>Range: %{customdata[0]:,.0f} – "
                    "%{customdata[1]:,.0f} tonnes<extra></extra>"
                ),
            )
        ]
    )
    figure.update_layout(
        **PLOT_LAYOUT,
        height=max(370, min(650, 265 + 24 * len(chart_predictions))),
        bargap=0.34,
        xaxis={
            "title": {"text": "Estimated production (tonnes)", "font": {"size": 11}},
            "gridcolor": "#edf1ec",
            "rangemode": "tozero",
            "zeroline": False,
            "tickformat": ",.0f",
        },
        yaxis={
            "automargin": True,
            "gridcolor": "rgba(0,0,0,0)",
            "tickfont": {"color": "#40574a", "size": 11},
        },
    )
    return figure


def _forecast_table_rows(
    predictions: list[dict[str, Any]],
) -> list[dict[str, Any]]:
    ordered = sorted(
        predictions,
        key=lambda prediction: float(prediction["production_tonnes"]),
        reverse=True,
    )
    return [
        {
            "rank": rank,
            "county": str(prediction["county"]),
            "production_tonnes": round(float(prediction["production_tonnes"]), 2),
            "lower_90_tonnes": round(float(prediction["lower_90_tonnes"]), 2),
            "upper_90_tonnes": round(float(prediction["upper_90_tonnes"]), 2),
        }
        for rank, prediction in enumerate(ordered, start=1)
    ]


def _forecast_csv(table_data: list[dict[str, Any]], year: int) -> str:
    output = io.StringIO(newline="")
    writer = csv.DictWriter(
        output,
        fieldnames=[
            "rank",
            "county",
            "year",
            "production_tonnes",
            "lower_90_tonnes",
            "upper_90_tonnes",
        ],
    )
    writer.writeheader()
    for row in table_data:
        writer.writerow(
            {
                "rank": row["rank"],
                "county": row["county"],
                "year": year,
                "production_tonnes": row["production_tonnes"],
                "lower_90_tonnes": row["lower_90_tonnes"],
                "upper_90_tonnes": row["upper_90_tonnes"],
            }
        )
    return output.getvalue()


def _load_dashboard_status(
    load_bundle: Callable[[], dict[str, Any]],
) -> dict[str, Any]:
    try:
        bundle = load_bundle()
    except HTTPException as error:
        if error.status_code == 409:
            return {"trained": False}
        raise

    history = bundle["history"]
    return {
        "trained": True,
        "latest_year": int(history["year"].max()),
        "records": int(len(history)),
        "county_count": int(history["county"].nunique()),
        "selected_model": bundle["selected_model"],
        "metrics": bundle["metrics"],
    }


def _format_tonnes(value: float) -> str:
    return f"{value:,.0f} t"


def _ranked_county_cards(
    predictions: list[dict[str, Any]],
    total_production: float,
) -> list[Any]:
    ranked = sorted(
        predictions,
        key=lambda prediction: float(prediction["production_tonnes"]),
        reverse=True,
    )[:5]
    return [
        html.Div(
            [
                html.Div(
                    [
                        html.Span(f"{rank:02d}", className="rank-number"),
                        html.Span(str(prediction["county"]), className="rank-county"),
                    ],
                    className="rank-heading",
                ),
                html.Div(
                    [
                        html.Strong(
                            _format_tonnes(float(prediction["production_tonnes"])),
                            className="rank-production",
                        ),
                        html.Span(
                            (
                                f"{float(prediction['production_tonnes']) / total_production:.1%}"
                                if total_production
                                else "0.0%"
                            ),
                            className="rank-share",
                        ),
                    ],
                    className="rank-values",
                ),
                html.Div(
                    [
                        html.Div(
                            className="rank-bar-fill",
                            style={
                                "width": (
                                    f"{float(prediction['production_tonnes']) / float(ranked[0]['production_tonnes']) * 100:.2f}%"
                                    if ranked and float(ranked[0]["production_tonnes"])
                                    else "0%"
                                )
                            },
                        )
                    ],
                    className="rank-bar",
                ),
            ],
            className="rank-item",
        )
        for rank, prediction in enumerate(ranked, start=1)
    ]


def create_dashboard(load_bundle: Callable[[], dict[str, Any]]) -> Dash:
    dashboard = Dash(
        __name__,
        title="MAIZE PREDICTION SYSTEM FOR KENYA",
        update_title=None,
        assets_folder="assets",
    )
    dashboard.layout = html.Main(
        [
            dcc.Interval(id="status-refresh", interval=60_000, n_intervals=0),
            dcc.Download(id="forecast-download"),
            dcc.Store(id="forecast-year-store"),
            html.Nav(
                [
                    html.Div(
                        [
                            html.Div("M", className="brand-mark"),
                            html.Div(
                                [
                                    html.Strong("KENYA AGRI OUTLOOK"),
                                    html.Span("MAIZE PRODUCTION INTELLIGENCE"),
                                ],
                                className="brand-copy",
                            ),
                        ],
                        className="brand-lockup",
                    ),
                    html.Div(
                        [
                            html.Span(
                                "DASHBOARD 1.5",
                                className="version-pill",
                            ),
                            html.A("API & data tools  ↗", href="/docs", className="nav-link"),
                        ],
                        className="nav-actions",
                    ),
                ],
                className="topbar",
            ),
            html.Header(
                [
                    html.Div(
                        [
                            html.Div(
                                [
                                    html.P(
                                        "KENYA · 47 COUNTIES · MAIZE",
                                        className="hero-eyebrow",
                                    ),
                                    html.H1(
                                        [
                                            "A clearer view of ",
                                            html.Span("Kenya’s harvest.", className="hero-highlight"),
                                        ],
                                        className="hero-title",
                                    ),
                                    html.P(
                                        "Explore county-level production forecasts, compare "
                                        "regional contributions, and plan for the next season.",
                                        className="hero-description",
                                    ),
                                ],
                                className="hero-copy",
                            ),
                            html.Div(
                                [
                                    html.Span(className="status-dot"),
                                    html.Span(id="model-status", children="Checking model"),
                                ],
                                className="model-status-pill",
                            ),
                        ],
                        className="hero-inner",
                    )
                ],
                className="hero-banner",
            ),
            html.Div(
                [
                    html.Section(
                        [
                            html.Div(
                                [
                                    html.Span("01", className="metric-index"),
                                    html.Span("LATEST OBSERVED SEASON", className="metric-label"),
                                    html.Strong(id="latest-year", children="—", className="metric-value"),
                                    html.Span("Historical data", className="metric-footnote"),
                                ],
                                className="metric-card",
                            ),
                            html.Div(
                                [
                                    html.Span("02", className="metric-index"),
                                    html.Span("FORECAST SEASON", className="metric-label"),
                                    html.Strong(id="forecast-year", children="—", className="metric-value"),
                                    html.Span("One step ahead", className="metric-footnote"),
                                ],
                                className="metric-card metric-card-accent",
                            ),
                            html.Div(
                                [
                                    html.Span("03", className="metric-index"),
                                    html.Span("COUNTIES COVERED", className="metric-label"),
                                    html.Strong(id="county-count", children="—", className="metric-value"),
                                    html.Span("Nationwide outlook", className="metric-footnote"),
                                ],
                                className="metric-card",
                            ),
                            html.Div(
                                [
                                    html.Span("04", className="metric-index"),
                                    html.Span("HISTORICAL RECORDS", className="metric-label"),
                                    html.Strong(id="record-count", children="—", className="metric-value"),
                                    html.Span("County-year observations", className="metric-footnote"),
                                ],
                                className="metric-card",
                            ),
                        ],
                        className="metrics-grid",
                    ),
                    html.Section(
                        [
                            html.Div(
                                [
                                    html.Div(
                                        [
                                            html.P("SEASONAL OUTLOOK", className="section-eyebrow"),
                                            html.H2("County production forecast", className="section-title"),
                                            html.P(
                                                "Compare estimated maize output and explore how "
                                                "production is distributed across counties.",
                                                className="section-description",
                                            ),
                                        ],
                                        className="section-heading-copy",
                                    ),
                                    html.Div(
                                        [
                                            dcc.Dropdown(
                                                id="county-filter",
                                                options=[
                                                    {"label": county, "value": county}
                                                    for county in COUNTIES
                                                ],
                                                value=None,
                                                multi=True,
                                                searchable=True,
                                                clearable=True,
                                                placeholder="All counties",
                                                className="county-dropdown",
                                            ),
                                            html.Button(
                                                [
                                                    html.Span("↻", className="button-icon"),
                                                    " Refresh forecast",
                                                ],
                                                id="forecast-button",
                                                n_clicks=0,
                                                className="primary-button",
                                            ),
                                        ],
                                        className="forecast-actions",
                                    ),
                                ],
                                className="forecast-heading",
                            ),
                            html.Div(
                                [
                                    html.Div(
                                        [
                                            html.Span(className="status-dot status-dot-green"),
                                            html.Span(
                                                "Choose counties or keep the selection empty "
                                                "for all 47.",
                                                id="forecast-message",
                                            ),
                                        ],
                                        className="forecast-status-line",
                                        role="status",
                                    ),
                                    html.Div(
                                        [
                                            html.Div(
                                                [
                                                    html.Label(
                                                        "VIEW",
                                                        className="control-label",
                                                        htmlFor="chart-mode",
                                                    ),
                                                    dcc.RadioItems(
                                                        id="chart-mode",
                                                        options=[
                                                            {"label": "Ranked", "value": "ranked"},
                                                            {"label": "Share", "value": "share"},
                                                        ],
                                                        value="ranked",
                                                        inline=True,
                                                        className="segmented-control",
                                                        inputClassName="segmented-input",
                                                        labelClassName="segmented-option",
                                                    ),
                                                ],
                                                className="view-control",
                                            ),
                                            html.Div(
                                                [
                                                    html.Label(
                                                        "COUNTIES IN CHART",
                                                        className="control-label",
                                                        htmlFor="top-counties",
                                                    ),
                                                    dcc.Slider(
                                                        id="top-counties",
                                                        min=5,
                                                        max=47,
                                                        step=1,
                                                        value=15,
                                                        marks={
                                                            5: "5",
                                                            15: "15",
                                                            30: "30",
                                                            47: "47",
                                                        },
                                                        tooltip={
                                                            "placement": "bottom",
                                                            "always_visible": False,
                                                        },
                                                        className="county-slider",
                                                    ),
                                                ],
                                                className="slider-control",
                                            ),
                                            dcc.Checklist(
                                                id="show-ranges",
                                                options=[
                                                    {
                                                        "label": "Estimate ranges",
                                                        "value": "show",
                                                    }
                                                ],
                                                value=["show"],
                                                className="range-toggle",
                                                inputClassName="range-input",
                                                labelClassName="range-label",
                                            ),
                                        ],
                                        className="chart-controls",
                                    ),
                                ],
                                className="chart-toolbar",
                            ),
                            html.Div(
                                [
                                    html.Div(
                                        dcc.Graph(
                                            id="forecast-chart",
                                            figure=_empty_figure(),
                                            config={
                                                "displaylogo": False,
                                                "responsive": True,
                                                "scrollZoom": True,
                                                "toImageButtonOptions": {
                                                    "format": "png",
                                                    "filename": "kenya-maize-forecast",
                                                },
                                            },
                                            className="forecast-graph",
                                        ),
                                        className="chart-panel",
                                    ),
                                    html.Aside(
                                        [
                                            html.Div(
                                                [
                                                    html.P("NATIONAL ESTIMATE", className="section-eyebrow"),
                                                    html.Strong(
                                                        "—",
                                                        id="national-production",
                                                        className="national-value",
                                                    ),
                                                    html.Span(
                                                        "tonnes across selected counties",
                                                        className="national-caption",
                                                    ),
                                                ],
                                                className="national-total",
                                            ),
                                            html.Div(
                                                [
                                                    html.P("LEADING COUNTIES", className="section-eyebrow"),
                                                    html.Div(
                                                        id="top-counties-list",
                                                        children=[
                                                            html.P(
                                                                "Generate a forecast to see the county leaders.",
                                                                className="empty-ranking",
                                                            )
                                                        ],
                                                        className="ranking-list",
                                                    ),
                                                ],
                                                className="ranking-section",
                                            ),
                                        ],
                                        className="insights-panel",
                                    ),
                                ],
                                className="visualization-grid",
                            ),
                            html.Div(
                                [
                                    html.Div(
                                        [
                                            html.Div(
                                                [
                                                    html.P("COUNTY DETAIL", className="section-eyebrow"),
                                                    html.H3("Forecast estimates", className="table-title"),
                                                ]
                                            ),
                                            html.Button(
                                                "Download CSV  ↓",
                                                id="download-button",
                                                n_clicks=0,
                                                className="secondary-button",
                                            ),
                                        ],
                                        className="table-heading",
                                    ),
                                    dash_table.DataTable(
                                        id="forecast-table",
                                        columns=[
                                            {"name": "#", "id": "rank", "type": "numeric"},
                                            {"name": "County", "id": "county"},
                                            {
                                                "name": "Forecast (tonnes)",
                                                "id": "production_tonnes",
                                                "type": "numeric",
                                                "format": {"specifier": ",.0f"},
                                            },
                                            {
                                                "name": "Lower estimate",
                                                "id": "lower_90_tonnes",
                                                "type": "numeric",
                                                "format": {"specifier": ",.0f"},
                                            },
                                            {
                                                "name": "Upper estimate",
                                                "id": "upper_90_tonnes",
                                                "type": "numeric",
                                                "format": {"specifier": ",.0f"},
                                            },
                                        ],
                                        data=[],
                                        page_size=12,
                                        page_action="native",
                                        sort_action="native",
                                        filter_action="native",
                                        style_table={
                                            "overflowX": "auto",
                                            "borderRadius": "12px",
                                        },
                                        style_cell={
                                            "border": "0",
                                            "fontFamily": "Inter, Segoe UI, sans-serif",
                                            "fontSize": "13px",
                                            "height": "46px",
                                            "padding": "8px 14px",
                                            "textAlign": "left",
                                            "whiteSpace": "normal",
                                        },
                                        style_header={
                                            "backgroundColor": "#f4f7f3",
                                            "borderBottom": "1px solid #e8eee8",
                                            "color": "#68766d",
                                            "fontSize": "10px",
                                            "fontWeight": "700",
                                            "letterSpacing": "0.8px",
                                            "textTransform": "uppercase",
                                        },
                                        style_data={
                                            "borderBottom": "1px solid #eef2ed",
                                            "color": INK,
                                        },
                                        style_data_conditional=[
                                            {
                                                "if": {"row_index": "odd"},
                                                "backgroundColor": "#fbfcfa",
                                            }
                                        ],
                                    ),
                                ],
                                className="table-section",
                            ),
                            html.Div(
                                [
                                    html.Span("READ THE OUTLOOK"),
                                    html.Span(
                                        "Forecasts use historical observations and the "
                                        "selected model shown above. Ranges are indicative "
                                        "estimates, not calibrated confidence intervals."
                                    ),
                                ],
                                className="forecast-disclaimer",
                            ),
                        ],
                        className="dashboard-card",
                    ),
                    html.Footer(
                        [
                            html.Span("KENYA AGRI OUTLOOK"),
                            html.Span(
                                "Planning support for a changing season · Historical data "
                                "may not represent current conditions."
                            ),
                        ],
                        className="page-footer",
                    ),
                ],
                className="page-content",
            ),
        ],
        className="app-shell",
    )

    @dashboard.callback(
        Output("model-status", "children"),
        Output("model-status", "className"),
        Output("latest-year", "children"),
        Output("forecast-year", "children"),
        Output("record-count", "children"),
        Output("county-count", "children"),
        Input("status-refresh", "n_intervals"),
    )
    def update_status(_: int) -> tuple[Any, str, str, str, str, str]:
        status = _load_dashboard_status(load_bundle)
        if not status["trained"]:
            return (
                html.Span(
                    [
                        html.Span(className="status-dot"),
                        "Model needs training",
                    ]
                ),
                "model-status-pill model-status-warning",
                "—",
                "—",
                "—",
                "—",
            )
        return (
            html.Span(
                [
                    html.Span(className="status-dot"),
                    "Forecast model ready",
                ]
            ),
            "model-status-pill",
            str(status["latest_year"]),
            str(status["latest_year"] + 1),
            f'{status["records"]:,}',
            f'{status["county_count"]} / 47',
        )

    @dashboard.callback(
        Output("forecast-chart", "figure"),
        Output("forecast-table", "data"),
        Output("forecast-message", "children"),
        Output("national-production", "children"),
        Output("top-counties-list", "children"),
        Output("forecast-year-store", "data"),
        Input("forecast-button", "n_clicks"),
        Input("county-filter", "value"),
        Input("chart-mode", "value"),
        Input("top-counties", "value"),
        Input("show-ranges", "value"),
    )
    def update_forecast(
        clicks: int,
        selected_counties: list[str] | None,
        chart_mode: str,
        top_counties: int,
        show_ranges: list[str] | None,
    ) -> tuple[Any, Any, str, str, Any, Any]:
        if not clicks:
            return (
                _empty_figure(),
                [],
                "Choose counties or keep the selection empty for all 47.",
                "—",
                [
                    html.P(
                        "Generate a forecast to see the county leaders.",
                        className="empty-ranking",
                    )
                ],
                no_update,
            )
        if selected_counties is None:
            selected_counties = list(COUNTIES)
        elif not selected_counties:
            return (
                _empty_figure(),
                [],
                "Select at least one county, or clear the search box for all counties.",
                "—",
                [],
                no_update,
            )

        try:
            bundle = load_bundle()
        except HTTPException as error:
            if error.status_code == 409:
                return (
                    _empty_figure(),
                    [],
                    "No trained model is available. Upload historical data through the API docs.",
                    "—",
                    [],
                    no_update,
                )
            raise

        year = int(bundle["history"]["year"].max()) + 1
        try:
            predictions = predict_counties(
                bundle,
                year,
                [{"county": county} for county in COUNTIES],
            )
        except DatasetError as error:
            return _empty_figure(), [], str(error), "—", [], no_update

        filtered = [
            prediction
            for prediction in predictions
            if prediction["county"] in selected_counties
        ]
        filtered.sort(
            key=lambda prediction: float(prediction["production_tonnes"]),
            reverse=True,
        )
        total_production = sum(
            float(prediction["production_tonnes"]) for prediction in filtered
        )
        figure = _create_forecast_figure(
            filtered,
            chart_mode,
            top_counties,
            "show" in (show_ranges or []),
        )
        table_data = _forecast_table_rows(filtered)
        model_name = bundle["selected_model"].replace("_", " ")
        return (
            figure,
            table_data,
            (
                f"Showing {len(filtered)} of 47 counties · {year} forecast · "
                f"{model_name.title()} model"
            ),
            _format_tonnes(total_production),
            _ranked_county_cards(filtered, total_production),
            year,
        )

    @dashboard.callback(
        Output("forecast-download", "data"),
        Input("download-button", "n_clicks"),
        State("forecast-table", "data"),
        State("forecast-table", "derived_virtual_data"),
        State("forecast-year-store", "data"),
        prevent_initial_call=True,
    )
    def download_forecast(
        clicks: int,
        table_data: list[dict[str, Any]] | None,
        visible_table_data: list[dict[str, Any]] | None,
        year: int | None,
    ) -> Any:
        if visible_table_data is not None:
            table_data = visible_table_data
        if not clicks or not table_data or year is None:
            return no_update
        return dcc.send_string(
            _forecast_csv(table_data, year),
            f"kenya_maize_forecast_{year}.csv",
        )

    return dashboard
