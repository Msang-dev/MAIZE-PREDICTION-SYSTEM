from __future__ import annotations

from collections.abc import Callable
from typing import Any

import plotly.graph_objects as go
from dash import Dash, Input, Output, State, dash_table, dcc, html
from fastapi import HTTPException

from app.model import COUNTIES, DatasetError, predict_counties


PAGE_STYLE = {
    "backgroundColor": "#f4f7f2",
    "color": "#20352b",
    "fontFamily": "Arial, sans-serif",
    "minHeight": "100vh",
    "padding": "32px 5vw 56px",
}
CARD_STYLE = {
    "backgroundColor": "#ffffff",
    "border": "1px solid #e1e9e1",
    "borderRadius": "14px",
    "boxShadow": "0 6px 24px rgba(32, 53, 43, 0.06)",
    "padding": "22px",
}


def _empty_figure() -> go.Figure:
    figure = go.Figure()
    figure.update_layout(
        template="plotly_white",
        margin={"l": 20, "r": 20, "t": 20, "b": 20},
        xaxis={"visible": False},
        yaxis={"visible": False},
        annotations=[
            {
                "text": "Generate a forecast to see county estimates.",
                "showarrow": False,
                "font": {"color": "#63766a", "size": 15},
            }
        ],
    )
    return figure


def _load_dashboard_status(
    load_bundle: Callable[[], dict[str, Any]],
) -> dict[str, Any]:
    try:
        bundle = load_bundle()
    except HTTPException as error:
        if error.status_code == 409:
            return {"trained": False}
        raise

    history = bundle["history"]
    return {
        "trained": True,
        "latest_year": int(history["year"].max()),
        "records": int(len(history)),
        "county_count": int(history["county"].nunique()),
        "selected_model": bundle["selected_model"],
        "metrics": bundle["metrics"],
    }


def create_dashboard(load_bundle: Callable[[], dict[str, Any]]) -> Dash:
    dashboard = Dash(
        __name__,
        title="MAIZE PREDICTION SYSTEM FOR KENYA",
        update_title=None,
    )
    dashboard.layout = html.Main(
        [
            dcc.Interval(id="status-refresh", interval=60_000, n_intervals=0),
            html.Header(
                [
                    html.P(
                        "KENYA · COUNTY-LEVEL CROP OUTLOOK",
                        style={
                            "color": "#47724e",
                            "fontSize": "12px",
                            "fontWeight": "700",
                            "letterSpacing": "1.5px",
                            "margin": "0 0 10px",
                        },
                    ),
                    html.H1(
                        "MAIZE PREDICTION SYSTEM FOR KENYA",
                        style={"fontSize": "clamp(28px, 4vw, 42px)", "margin": "0"},
                    ),
                    html.P(
                        "Explore next-season maize production estimates for all "
                        "47 counties, backed by historical county data.",
                        style={
                            "color": "#63766a",
                            "fontSize": "16px",
                            "lineHeight": "1.6",
                            "maxWidth": "720px",
                        },
                    ),
                    html.Div(
                        id="model-status",
                        style={
                            "fontSize": "14px",
                            "fontWeight": "700",
                            "marginTop": "18px",
                        },
                    ),
                ],
                style={"margin": "0 auto 28px", "maxWidth": "1200px"},
            ),
            html.Section(
                [
                    html.Div(
                        [
                            html.Span(
                                "Latest observed season",
                                style={"color": "#63766a", "fontSize": "13px"},
                            ),
                            html.Strong(id="latest-year", children="—"),
                        ],
                        style=CARD_STYLE | {"display": "grid", "gap": "12px"},
                    ),
                    html.Div(
                        [
                            html.Span(
                                "Historical records",
                                style={"color": "#63766a", "fontSize": "13px"},
                            ),
                            html.Strong(id="record-count", children="—"),
                        ],
                        style=CARD_STYLE | {"display": "grid", "gap": "12px"},
                    ),
                    html.Div(
                        [
                            html.Span(
                                "Counties represented",
                                style={"color": "#63766a", "fontSize": "13px"},
                            ),
                            html.Strong(id="county-count", children="—"),
                        ],
                        style=CARD_STYLE | {"display": "grid", "gap": "12px"},
                    ),
                    html.Div(
                        [
                            html.Span(
                                "Selected forecasting method",
                                style={"color": "#63766a", "fontSize": "13px"},
                            ),
                            html.Strong(id="selected-model", children="—"),
                        ],
                        style=CARD_STYLE | {"display": "grid", "gap": "12px"},
                    ),
                ],
                style={
                    "display": "grid",
                    "gap": "14px",
                    "gridTemplateColumns": "repeat(auto-fit, minmax(200px, 1fr))",
                    "margin": "0 auto 22px",
                    "maxWidth": "1200px",
                },
            ),
            html.Section(
                [
                    html.Div(
                        [
                            html.Div(
                                [
                                    html.H2(
                                        "County forecast",
                                        style={"fontSize": "21px", "margin": "0 0 8px"},
                                    ),
                                    html.P(
                                        id="forecast-year",
                                        children="The forecast year is based on the latest observed data.",
                                        style={"color": "#63766a", "margin": "0"},
                                    ),
                                ]
                            ),
                            html.Div(
                                [
                                    dcc.Dropdown(
                                        id="county-filter",
                                        options=[
                                            {"label": county, "value": county}
                                            for county in COUNTIES
                                        ],
                                        value=list(COUNTIES),
                                        multi=True,
                                        placeholder="Choose counties to display",
                                        style={"minWidth": "260px"},
                                    ),
                                    html.Button(
                                        "Generate next-season forecast",
                                        id="forecast-button",
                                        n_clicks=0,
                                        style={
                                            "backgroundColor": "#287747",
                                            "border": "0",
                                            "borderRadius": "8px",
                                            "color": "#ffffff",
                                            "cursor": "pointer",
                                            "fontSize": "14px",
                                            "fontWeight": "700",
                                            "padding": "13px 18px",
                                        },
                                    ),
                                ],
                                style={
                                    "alignItems": "center",
                                    "display": "flex",
                                    "flexWrap": "wrap",
                                    "gap": "12px",
                                },
                            ),
                        ],
                        style={
                            "alignItems": "center",
                            "display": "flex",
                            "flexWrap": "wrap",
                            "gap": "20px",
                            "justifyContent": "space-between",
                            "marginBottom": "18px",
                        },
                    ),
                    html.Div(
                        id="forecast-message",
                        role="status",
                        style={"color": "#63766a", "fontSize": "14px", "marginBottom": "12px"},
                    ),
                    dcc.Graph(
                        id="forecast-chart",
                        figure=_empty_figure(),
                        config={"displaylogo": False, "responsive": True},
                    ),
                    dash_table.DataTable(
                        id="forecast-table",
                        columns=[
                            {"name": "County", "id": "county"},
                            {"name": "Forecast (tonnes)", "id": "production_tonnes", "type": "numeric", "format": {"specifier": ",.0f"}},
                            {"name": "Lower estimate", "id": "lower_90_tonnes", "type": "numeric", "format": {"specifier": ",.0f"}},
                            {"name": "Upper estimate", "id": "upper_90_tonnes", "type": "numeric", "format": {"specifier": ",.0f"}},
                        ],
                        data=[],
                        page_size=15,
                        sort_action="native",
                        style_table={"overflowX": "auto"},
                        style_cell={
                            "border": "0",
                            "fontFamily": "Arial, sans-serif",
                            "padding": "12px",
                            "textAlign": "left",
                        },
                        style_header={
                            "backgroundColor": "#eff5ee",
                            "color": "#375a3c",
                            "fontWeight": "700",
                        },
                        style_data_conditional=[
                            {
                                "if": {"row_index": "odd"},
                                "backgroundColor": "#fafcf9",
                            }
                        ],
                    ),
                    html.P(
                        "Estimate ranges are approximate, not calibrated confidence "
                        "intervals. Forecasts are limited to one season beyond the "
                        "latest historical data.",
                        style={
                            "color": "#63766a",
                            "fontSize": "12px",
                            "lineHeight": "1.5",
                            "marginTop": "18px",
                        },
                    ),
                ],
                style=CARD_STYLE | {"margin": "0 auto", "maxWidth": "1156px"},
            ),
            html.Footer(
                "Forecasts are decision-support estimates and should be considered "
                "alongside local agricultural expertise and current field data.",
                style={
                    "color": "#63766a",
                    "fontSize": "12px",
                    "margin": "18px auto 0",
                    "maxWidth": "1200px",
                },
            ),
        ],
        style=PAGE_STYLE,
    )

    @dashboard.callback(
        Output("model-status", "children"),
        Output("latest-year", "children"),
        Output("record-count", "children"),
        Output("county-count", "children"),
        Output("selected-model", "children"),
        Output("forecast-year", "children"),
        Input("status-refresh", "n_intervals"),
    )
    def update_status(_: int) -> tuple[str, str, str, str, str, str]:
        status = _load_dashboard_status(load_bundle)
        if not status["trained"]:
            return (
                "Model not trained — upload the historical workbook through the API docs.",
                "—",
                "—",
                "—",
                "—",
                "Forecasting is unavailable until a dataset has been trained.",
            )
        return (
            "Model ready",
            str(status["latest_year"]),
            f"{status['records']:,}",
            f'{status["county_count"]} / 47',
            status["selected_model"].replace("_", " ").title(),
            f'Next forecast: {status["latest_year"] + 1}',
        )

    @dashboard.callback(
        Output("forecast-chart", "figure"),
        Output("forecast-table", "data"),
        Output("forecast-message", "children"),
        Input("forecast-button", "n_clicks"),
        Input("county-filter", "value"),
        State("status-refresh", "n_intervals"),
    )
    def update_forecast(
        clicks: int,
        selected_counties: list[str] | None,
        _: int,
    ) -> tuple[go.Figure, list[dict[str, Any]], str]:
        if not clicks:
            return _empty_figure(), [], "Select counties and generate a forecast."
        if not selected_counties:
            return _empty_figure(), [], "Select at least one county to display."

        try:
            bundle = load_bundle()
        except HTTPException as error:
            if error.status_code == 409:
                return (
                    _empty_figure(),
                    [],
                    "No trained model is available. Upload the historical workbook through the API docs.",
                )
            raise

        year = int(bundle["history"]["year"].max()) + 1
        try:
            predictions = predict_counties(
                bundle,
                year,
                [{"county": county} for county in COUNTIES],
            )
        except DatasetError as error:
            return _empty_figure(), [], str(error)

        visible_predictions = [
            prediction
            for prediction in predictions
            if prediction["county"] in selected_counties
        ]
        visible_predictions.sort(
            key=lambda prediction: float(prediction["production_tonnes"]),
            reverse=True,
        )
        figure = go.Figure(
            data=[
                go.Bar(
                    x=[prediction["county"] for prediction in visible_predictions],
                    y=[
                        prediction["production_tonnes"]
                        for prediction in visible_predictions
                    ],
                    marker_color="#398657",
                    error_y={
                        "type": "data",
                        "symmetric": False,
                        "array": [
                            max(
                                float(prediction["upper_90_tonnes"])
                                - float(prediction["production_tonnes"]),
                                0,
                            )
                            for prediction in visible_predictions
                        ],
                        "arrayminus": [
                            max(
                                float(prediction["production_tonnes"])
                                - float(prediction["lower_90_tonnes"]),
                                0,
                            )
                            for prediction in visible_predictions
                        ],
                        "color": "#78917c",
                    },
                    hovertemplate="%{x}<br>%{y:,.0f} tonnes<extra></extra>",
                )
            ]
        )
        figure.update_layout(
            template="plotly_white",
            height=390,
            margin={"l": 30, "r": 20, "t": 15, "b": 80},
            xaxis_title=None,
            yaxis_title="Estimated production (tonnes)",
            xaxis={"tickangle": -45},
            showlegend=False,
        )
        return (
            figure,
            visible_predictions,
            f"Showing {len(visible_predictions)} county forecast(s) for {year}.",
        )

    return dashboard
