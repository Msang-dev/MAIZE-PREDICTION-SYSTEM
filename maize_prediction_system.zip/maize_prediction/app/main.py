from __future__ import annotations

import hmac
import os
from pathlib import Path
from typing import Any
from uuid import uuid4

import joblib
from a2wsgi import WSGIMiddleware
from fastapi import FastAPI, File, Header, HTTPException, UploadFile
from pydantic import BaseModel, ConfigDict

from app.dashboard import create_dashboard
from app.data_import import read_history
from app.model import COUNTIES, DatasetError, predict_counties, train_model


MODEL_PATH = Path(
    os.environ.get(
        "MAIZE_MODEL_PATH",
        str(Path(__file__).resolve().parents[1] / "data" / "maize_model.joblib"),
    )
)
MAX_UPLOAD_BYTES = 50 * 1024 * 1024
ADMIN_TOKEN_ENV = "MAIZE_ADMIN_TOKEN"

app = FastAPI(
    title="MAIZE PREDICTION SYSTEM FOR KENYA",
    version="1.0.0",
    description=(
        "Train and forecast maize production for Kenya's 47 counties from "
        "historical county-season data."
    ),
)


class CountyScenario(BaseModel):
    model_config = ConfigDict(extra="forbid")

    county: str


class ForecastRequest(BaseModel):
    model_config = ConfigDict(extra="forbid")

    year: int
    scenarios: list[CountyScenario]


def _load_bundle() -> dict[str, Any]:
    if not MODEL_PATH.is_file():
        raise HTTPException(
            status_code=409,
            detail="No trained model is available. Upload historical CSV data to /api/v1/train first.",
        )
    return joblib.load(MODEL_PATH)


@app.get("/api/v1/health")
def health() -> dict[str, str]:
    return {"status": "ok"}


@app.get("/api/v1/counties")
def counties() -> dict[str, list[str]]:
    return {"counties": list(COUNTIES)}


@app.get("/api/v1/model/status")
def model_status() -> dict[str, Any]:
    if not MODEL_PATH.is_file():
        return {"trained": False}
    bundle = _load_bundle()
    history = bundle["history"]
    return {
        "trained": True,
        "trained_at": bundle["trained_at"],
        "latest_historical_year": int(history["year"].max()),
        "historical_rows": int(len(history)),
        "county_count": int(history["county"].nunique()),
        "historical_years": sorted(int(year) for year in history["year"].unique()),
        "selected_model": bundle["selected_model"],
        "driver_columns": bundle["driver_columns"],
        "metrics": bundle["metrics"],
    }


@app.post("/api/v1/train")
async def train(
    file: UploadFile = File(...),
    authorization: str | None = Header(default=None),
) -> dict[str, Any]:
    configured_token = os.environ.get(ADMIN_TOKEN_ENV)
    if not configured_token:
        raise HTTPException(
            status_code=503,
            detail=f"Training is disabled until {ADMIN_TOKEN_ENV} is configured.",
        )
    supplied_token = (
        authorization.removeprefix("Bearer ").strip()
        if authorization and authorization.startswith("Bearer ")
        else ""
    )
    if not hmac.compare_digest(
        supplied_token.encode("utf-8"),
        configured_token.encode("utf-8"),
    ):
        raise HTTPException(
            status_code=401,
            detail="Provide the training token in the Authorization: Bearer header.",
            headers={"WWW-Authenticate": "Bearer"},
        )
    if not file.filename or Path(file.filename).suffix.casefold() not in {
        ".csv",
        ".xlsx",
        ".xlsm",
    }:
        raise HTTPException(
            status_code=422,
            detail="Upload a .csv or .xlsx workbook.",
        )
    contents = await file.read(MAX_UPLOAD_BYTES + 1)
    if len(contents) > MAX_UPLOAD_BYTES:
        raise HTTPException(
            status_code=413,
            detail=f"CSV upload exceeds the {MAX_UPLOAD_BYTES // (1024 * 1024)} MB limit.",
        )
    try:
        history = read_history(file.filename, contents)
        bundle = train_model(history)
    except DatasetError as error:
        raise HTTPException(status_code=422, detail=str(error)) from error
    except ValueError as error:
        raise HTTPException(status_code=422, detail=f"Invalid CSV data: {error}") from error

    MODEL_PATH.parent.mkdir(parents=True, exist_ok=True)
    temporary_path = MODEL_PATH.with_name(
        MODEL_PATH.name + f".{uuid4().hex}.tmp"
    )
    try:
        joblib.dump(bundle, temporary_path)
        os.replace(temporary_path, MODEL_PATH)
    except OSError as error:
        raise HTTPException(status_code=500, detail="Could not save the trained model.") from error
    finally:
        temporary_path.unlink(missing_ok=True)

    return {
        "trained": True,
        "trained_at": bundle["trained_at"],
        "latest_historical_year": int(bundle["history"]["year"].max()),
        "historical_rows": int(len(bundle["history"])),
        "county_count": int(bundle["history"]["county"].nunique()),
        "historical_years": sorted(
            int(year) for year in bundle["history"]["year"].unique()
        ),
        "driver_columns": bundle["driver_columns"],
        "selected_model": bundle["selected_model"],
        "metrics": bundle["metrics"],
        "note": (
            "The random forest is selected only when both holdout MAE and RMSE "
            "beat the three-observation-mean baseline. The holdout is the most "
            "recent historical year. Forecast ranges are approximate and not "
            "calibrated confidence intervals."
        ),
    }


@app.post("/api/v1/predict")
def predict(request: ForecastRequest) -> dict[str, Any]:
    bundle = _load_bundle()
    scenarios = [{"county": scenario.county} for scenario in request.scenarios]
    try:
        predictions = predict_counties(bundle, request.year, scenarios)
    except DatasetError as error:
        raise HTTPException(status_code=422, detail=str(error)) from error
    return {
        "year": request.year,
        "unit": "tonnes",
        "uncertainty_note": (
            "Ranges use either fitted-tree spread or the 95th percentile of "
            "absolute holdout errors, depending on the selected model. They "
            "are approximate, not calibrated confidence intervals."
        ),
        "selected_model": bundle["selected_model"],
        "predictions": predictions,
    }


dashboard = create_dashboard(_load_bundle)
app.mount("/", WSGIMiddleware(dashboard.server))
