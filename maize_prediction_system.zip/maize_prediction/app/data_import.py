from __future__ import annotations

import io
import re
from pathlib import Path

import pandas as pd

from app.model import COUNTIES, DatasetError


def _column_key(value: object) -> str:
    return re.sub(r"[^a-z0-9]", "", str(value).casefold())


COUNTY_LOOKUP = {_column_key(county): county for county in COUNTIES}
COUNTY_LOOKUP.update(
    {
        "homabay": "Homa Bay",
        "elgeyomarakwet": "Elgeyo-Marakwet",
        "taitataveta": "Taita-Taveta",
        "tharakanthi": "Tharaka-Nithi",
    }
)


def _canonical_county(value: object) -> str | None:
    if pd.isna(value):
        return None
    return COUNTY_LOOKUP.get(_column_key(value))


def _tidy_history(frame: pd.DataFrame) -> pd.DataFrame:
    columns = {_column_key(column): column for column in frame.columns}
    if not {"county", "year", "indicator", "value"}.issubset(columns):
        raise DatasetError(
            "Excel sheets must contain County, Year, Indicator, and Value columns."
        )

    data = frame.rename(
        columns={
            columns["county"]: "county",
            columns["year"]: "year",
            columns["indicator"]: "indicator",
            columns["value"]: "value",
        }
    )[["county", "year", "indicator", "value"]].copy()
    data["county"] = data["county"].map(_canonical_county)
    if data["county"].isna().any():
        raise DatasetError(
            "The workbook contains county names that do not match Kenya's "
            "official 47 county names."
        )

    indicators = {
        _column_key(indicator): label
        for indicator, label in (
            ("Production (MT)", "production_tonnes"),
            ("Area (HA)", "area_ha"),
            ("Harvested Area (HA)", "area_ha"),
            ("Yield(MT/HA)", "yield_tonnes_per_ha"),
            ("Yield (MT/HA)", "yield_tonnes_per_ha"),
        )
    }
    data["feature"] = data["indicator"].map(
        lambda value: indicators.get(_column_key(value))
    )
    unsupported = sorted(data.loc[data["feature"].isna(), "indicator"].astype(str).unique())
    if unsupported:
        raise DatasetError(
            "Unsupported workbook indicators: " + ", ".join(unsupported)
        )
    duplicates = data.duplicated(["county", "year", "feature"], keep=False)
    if duplicates.any():
        raise DatasetError(
            "The workbook has multiple values for a county, year, and indicator."
        )
    wide = data.pivot(
        index=["county", "year"],
        columns="feature",
        values="value",
    ).reset_index()
    wide.columns.name = None
    if "production_tonnes" not in wide.columns:
        raise DatasetError("No maize production indicator was found in the workbook.")
    return wide


def _wide_history(frame: pd.DataFrame) -> pd.DataFrame:
    normalized = {_column_key(column): column for column in frame.columns}
    county_column = normalized.get("county")
    if county_column is None:
        raise DatasetError("Wide-format Excel sheets must have a COUNTY column.")

    record_columns: dict[int, dict[str, object]] = {}
    for column in frame.columns:
        key = _column_key(column)
        if column == county_column:
            continue
        year_match = re.search(r"(?:19|20)\d{2}", str(column))
        if not year_match:
            continue
        year = int(year_match.group())
        if "production" in key or "quantity" in key:
            record_columns.setdefault(year, {})["production_tonnes"] = column
        elif "area" in key:
            record_columns.setdefault(year, {})["area_ha"] = column
        elif "yield" in key:
            record_columns.setdefault(year, {})["yield_tonnes_per_ha"] = column

    rows = []
    for year, columns in record_columns.items():
        production_column = columns.get("production_tonnes")
        if production_column is None:
            continue
        annual = pd.DataFrame(
            {
                "county": frame[county_column].map(_canonical_county),
                "year": year,
                "production_tonnes": frame[production_column],
            }
        )
        for feature in ("area_ha", "yield_tonnes_per_ha"):
            if feature in columns:
                annual[feature] = frame[columns[feature]]
        rows.append(annual)
    if not rows:
        raise DatasetError(
            "No yearly production columns were found in the wide-format sheet."
        )
    return pd.concat(rows, ignore_index=True)


def read_history(filename: str, contents: bytes) -> pd.DataFrame:
    suffix = Path(filename).suffix.casefold()
    try:
        if suffix == ".csv":
            return pd.read_csv(io.BytesIO(contents))
        if suffix not in {".xlsx", ".xlsm"}:
            raise DatasetError("Upload a .csv or .xlsx workbook.")

        sheets = pd.read_excel(io.BytesIO(contents), sheet_name=None)
    except DatasetError:
        raise
    except (UnicodeDecodeError, pd.errors.ParserError, pd.errors.EmptyDataError) as error:
        raise DatasetError(f"Could not read the data file: {error}") from error
    except (ValueError, ImportError, OSError) as error:
        raise DatasetError(f"Could not read the Excel workbook: {error}") from error

    candidates: list[pd.DataFrame] = []
    sheet_errors: list[str] = []
    for name, sheet in sheets.items():
        if sheet.empty:
            continue
        try:
            keys = {_column_key(column) for column in sheet.columns}
            if {"county", "year", "indicator", "value"}.issubset(keys):
                candidates.append(_tidy_history(sheet))
            else:
                candidates.append(_wide_history(sheet))
        except DatasetError as error:
            sheet_errors.append(f"{name}: {error}")
    if not candidates:
        detail = " ".join(sheet_errors)
        raise DatasetError(
            "No supported county production table was found in the workbook. "
            + detail
        )

    usable = [
        candidate
        for candidate in candidates
        if "production_tonnes" in candidate.columns
        and candidate["production_tonnes"].notna().any()
    ]
    if len(usable) != 1:
        raise DatasetError(
            "The workbook must contain exactly one supported county production table."
        )
    return usable[0]
