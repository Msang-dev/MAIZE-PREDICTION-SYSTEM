from __future__ import annotations

from datetime import datetime, timezone
from typing import Any

import numpy as np
import pandas as pd
from sklearn.compose import ColumnTransformer
from sklearn.ensemble import RandomForestRegressor
from sklearn.impute import SimpleImputer
from sklearn.metrics import mean_absolute_error, mean_squared_error, r2_score
from sklearn.pipeline import Pipeline
from sklearn.preprocessing import OneHotEncoder


COUNTIES = (
    "Mombasa",
    "Kwale",
    "Kilifi",
    "Tana River",
    "Lamu",
    "Taita-Taveta",
    "Garissa",
    "Wajir",
    "Mandera",
    "Marsabit",
    "Isiolo",
    "Meru",
    "Tharaka-Nithi",
    "Embu",
    "Kitui",
    "Machakos",
    "Makueni",
    "Nyandarua",
    "Nyeri",
    "Kirinyaga",
    "Murang'a",
    "Kiambu",
    "Turkana",
    "West Pokot",
    "Samburu",
    "Trans Nzoia",
    "Uasin Gishu",
    "Elgeyo-Marakwet",
    "Nandi",
    "Baringo",
    "Laikipia",
    "Nakuru",
    "Narok",
    "Kajiado",
    "Kericho",
    "Bomet",
    "Kakamega",
    "Vihiga",
    "Bungoma",
    "Busia",
    "Siaya",
    "Kisumu",
    "Homa Bay",
    "Migori",
    "Kisii",
    "Nyamira",
    "Nairobi",
)

REQUIRED_COLUMNS = {"county", "year", "production_tonnes"}
BASE_NUMERIC_FEATURES = [
    "year",
    "previous_production_tonnes",
    "previous_3_observation_mean_tonnes",
]
MIN_YEAR = 1900
MAX_YEAR = 2200


class DatasetError(ValueError):
    pass


def validate_history(data: pd.DataFrame) -> pd.DataFrame:
    if not data.columns.is_unique:
        raise DatasetError("CSV column names must be unique.")
    missing = REQUIRED_COLUMNS.difference(data.columns)
    if missing:
        raise DatasetError(
            "Missing required columns: " + ", ".join(sorted(missing))
        )

    frame = data.copy()
    frame["county"] = frame["county"].astype("string").str.strip()
    county_lookup = {county.casefold(): county for county in COUNTIES}
    frame["county"] = frame["county"].map(
        lambda value: county_lookup.get(value.casefold()) if pd.notna(value) else None
    )
    if frame["county"].isna().any():
        raise DatasetError(
            "County names must match Kenya's official 47 county names."
        )

    for column in ("year", "production_tonnes"):
        frame[column] = pd.to_numeric(frame[column], errors="coerce")
        if frame[column].isna().any() or not np.isfinite(frame[column]).all():
            raise DatasetError(f"{column} must contain only finite numbers.")

    if not np.equal(frame["year"], np.floor(frame["year"])).all():
        raise DatasetError("year must contain whole numbers.")
    if not frame["year"].between(MIN_YEAR, MAX_YEAR).all():
        raise DatasetError(f"year must be between {MIN_YEAR} and {MAX_YEAR}.")
    frame["year"] = frame["year"].astype(int)
    if (frame["production_tonnes"] < 0).any():
        raise DatasetError("production_tonnes cannot be negative.")

    duplicates = frame.duplicated(["county", "year"], keep=False)
    if duplicates.any():
        raise DatasetError("There must be only one row per county and year.")

    numeric_features = [column for column in frame.columns if column not in REQUIRED_COLUMNS]
    reserved_features = set(BASE_NUMERIC_FEATURES).intersection(numeric_features)
    if reserved_features:
        raise DatasetError(
            "CSV columns cannot use reserved model feature names: "
            + ", ".join(sorted(reserved_features))
        )
    for column in numeric_features:
        frame[column] = pd.to_numeric(frame[column], errors="coerce")
        invalid = frame[column].isna() & data[column].notna()
        if invalid.any() or not np.isfinite(frame[column].dropna()).all():
            raise DatasetError(f"{column} must contain only finite numbers or blanks.")

    missing_counties = sorted(set(COUNTIES).difference(frame["county"].unique()))
    if missing_counties:
        raise DatasetError(
            "The dataset must include at least one observation for every county; "
            "missing: " + ", ".join(missing_counties)
        )
    return frame.sort_values(["county", "year"]).reset_index(drop=True)


def _features_from_history(history: pd.DataFrame) -> tuple[pd.DataFrame, list[str]]:
    driver_columns = [
        column for column in history.columns if column not in REQUIRED_COLUMNS
    ]
    ordered = history.sort_values(["county", "year"]).copy()
    grouped = ordered.groupby("county", sort=False)["production_tonnes"]
    ordered["previous_production_tonnes"] = grouped.shift(1)
    ordered["previous_3_observation_mean_tonnes"] = grouped.transform(
        lambda values: values.shift(1).rolling(3, min_periods=1).mean()
    )
    for column in driver_columns:
        ordered[f"previous_{column}"] = ordered.groupby("county", sort=False)[
            column
        ].shift(1)
    features = ordered.dropna(subset=["previous_production_tonnes"]).copy()
    lag_features = [f"previous_{column}" for column in driver_columns]
    return features, lag_features


def _make_model(driver_columns: list[str]) -> Pipeline:
    numeric_columns = BASE_NUMERIC_FEATURES + driver_columns
    preprocessing = ColumnTransformer(
        transformers=[
            (
                "county",
                OneHotEncoder(handle_unknown="ignore"),
                ["county"],
            ),
            (
                "numeric",
                SimpleImputer(strategy="median"),
                numeric_columns,
            ),
        ],
        remainder="drop",
    )
    return Pipeline(
        steps=[
            ("preprocessor", preprocessing),
            (
                "regressor",
                RandomForestRegressor(
                    n_estimators=300,
                    min_samples_leaf=2,
                    max_features=0.9,
                    random_state=42,
                    n_jobs=-1,
                ),
            ),
        ]
    )


def train_model(history: pd.DataFrame) -> dict[str, Any]:
    validated = validate_history(history)
    engineered, driver_columns = _features_from_history(validated)
    if len(engineered) < 10:
        raise DatasetError(
            "Not enough county-season observations to train a model. Provide at "
            "least 10 rows with a previous production observation."
        )

    latest_year = int(engineered["year"].max())
    training = engineered[engineered["year"] < latest_year]
    holdout = engineered[engineered["year"] == latest_year]
    if training.empty or holdout.empty:
        raise DatasetError(
            "At least three years of historical production are needed for a "
            "time-based backtest and training."
        )
    evaluation_model = _make_model(driver_columns)
    evaluation_model.fit(
        training[["county"] + BASE_NUMERIC_FEATURES + driver_columns],
        training["production_tonnes"],
    )
    predictions = evaluation_model.predict(
        holdout[["county"] + BASE_NUMERIC_FEATURES + driver_columns]
    )
    actual = holdout["production_tonnes"].to_numpy()
    baseline_predictions = holdout["previous_3_observation_mean_tonnes"].to_numpy()
    model_mae = float(mean_absolute_error(actual, predictions))
    model_rmse = float(np.sqrt(mean_squared_error(actual, predictions)))
    baseline_mae = float(mean_absolute_error(actual, baseline_predictions))
    baseline_rmse = float(np.sqrt(mean_squared_error(actual, baseline_predictions)))
    use_random_forest = model_mae < baseline_mae and model_rmse < baseline_rmse
    selected_predictions = predictions if use_random_forest else baseline_predictions
    selected_model = "random_forest" if use_random_forest else "three_observation_mean"
    metrics: dict[str, Any] = {
        "held_out_year": latest_year,
        "training_rows": int(len(training)),
        "backtest_rows": int(len(holdout)),
        "selected_model": selected_model,
        "mae_tonnes": float(mean_absolute_error(actual, selected_predictions)),
        "rmse_tonnes": float(np.sqrt(mean_squared_error(actual, selected_predictions))),
        "r2": float(r2_score(actual, selected_predictions)),
        "random_forest_mae_tonnes": model_mae,
        "random_forest_rmse_tonnes": model_rmse,
        "three_observation_mean_mae_tonnes": baseline_mae,
        "three_observation_mean_rmse_tonnes": baseline_rmse,
    }

    feature_columns = ["county"] + BASE_NUMERIC_FEATURES + driver_columns
    model = _make_model(driver_columns)
    model.fit(engineered[feature_columns], engineered["production_tonnes"])
    return {
        "model": model,
        "history": validated,
        "driver_columns": driver_columns,
        "metrics": metrics,
        "selected_model": selected_model,
        "holdout_absolute_errors": np.abs(actual - selected_predictions),
        "trained_at": datetime.now(timezone.utc).isoformat(),
    }


def predict_counties(
    bundle: dict[str, Any],
    year: int,
    scenarios: list[dict[str, Any]],
) -> list[dict[str, float | str]]:
    history = bundle["history"]
    latest_year = int(history["year"].max())
    if year != latest_year + 1:
        raise DatasetError(
            f"Forecast year must be {latest_year + 1}, the next year after "
            "the latest historical data."
        )

    scenario_by_county: dict[str, dict[str, Any]] = {}
    for scenario in scenarios:
        county = scenario["county"]
        if county not in COUNTIES:
            raise DatasetError(f"Unknown county: {county}")
        if county in scenario_by_county:
            raise DatasetError(f"Duplicate forecast scenario for {county}.")
        scenario_by_county[county] = scenario
    missing_counties = sorted(set(COUNTIES).difference(scenario_by_county))
    unexpected_counties = sorted(set(scenario_by_county).difference(COUNTIES))
    if missing_counties or unexpected_counties or len(scenarios) != len(COUNTIES):
        raise DatasetError(
            "Provide exactly one forecast scenario for each of Kenya's 47 counties."
        )

    stale_counties = sorted(
        county
        for county in COUNTIES
        if int(history.loc[history["county"] == county, "year"].max()) != latest_year
    )
    if stale_counties:
        raise DatasetError(
            "The latest historical year must include production for every county; "
            "missing for that year: " + ", ".join(stale_counties)
        )

    rows: list[dict[str, Any]] = []
    for county in COUNTIES:
        county_history = history[history["county"] == county].sort_values("year")
        if county_history.empty:
            raise DatasetError(f"No historical production data is available for {county}.")
        prior_production = county_history["production_tonnes"].tolist()
        row: dict[str, Any] = {
            "county": county,
            "year": year,
            "previous_production_tonnes": float(prior_production[-1]),
            "previous_3_observation_mean_tonnes": float(
                np.mean(prior_production[-3:])
            ),
        }
        latest_observation = county_history.iloc[-1]
        for feature in bundle["driver_columns"]:
            history_column = feature.removeprefix("previous_")
            row[feature] = latest_observation[history_column]
        rows.append(row)

    feature_columns = ["county"] + BASE_NUMERIC_FEATURES + bundle["driver_columns"]
    features = pd.DataFrame(rows, columns=feature_columns)
    transformed = bundle["model"].named_steps["preprocessor"].transform(features)
    forest = bundle["model"].named_steps["regressor"]
    tree_predictions = np.stack(
        [tree.predict(transformed) for tree in forest.estimators_],
        axis=0,
    )
    if bundle["selected_model"] == "random_forest":
        means = np.maximum(tree_predictions.mean(axis=0), 0)
        lower = np.maximum(np.percentile(tree_predictions, 5, axis=0), 0)
        upper = np.maximum(np.percentile(tree_predictions, 95, axis=0), 0)
    else:
        means = features["previous_3_observation_mean_tonnes"].to_numpy()
        interval = float(np.percentile(bundle["holdout_absolute_errors"], 95))
        lower = np.maximum(means - interval, 0)
        upper = means + interval
    return [
        {
            "county": county,
            "production_tonnes": float(mean),
            "lower_90_tonnes": float(low),
            "upper_90_tonnes": float(high),
        }
        for county, mean, low, high in zip(COUNTIES, means, lower, upper)
    ]
