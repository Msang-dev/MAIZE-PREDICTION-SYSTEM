# MAIZE PREDICTION SYSTEM FOR KENYA

This Python application includes a Plotly Dash dashboard and a FastAPI service
for training a county-level maize production model and returning
one-season-ahead estimates for all 47 counties. It accepts CSV training data or
an Excel workbook containing either a tidy `County` / `Year` / `Indicator` /
`Value` table or a wide table with year-labelled production columns.

## Run locally

From this directory, create a virtual environment, install dependencies, and
start the dashboard and API:

```powershell
py -m venv .venv
.\.venv\Scripts\Activate.ps1
python -m pip install -r requirements.txt
uvicorn app.main:app --reload
```

The dashboard is at `http://127.0.0.1:8000/`, and interactive API
documentation is at `http://127.0.0.1:8000/docs`. The API
binds to localhost by default; do not expose it to a public network without
adding authentication and access controls.
Set a long random `MAIZE_ADMIN_TOKEN` before training. Send it as
`Authorization: Bearer <token>` when uploading a training file. Training
returns HTTP 503 when the token is not configured and HTTP 401 when it is
incorrect.

## Historical data

For CSV input, provide one row per county and season with:

| Column | Meaning |
| --- | --- |
| `county` | Official Kenyan county name |
| `year` | Integer season/year |
| `production_tonnes` | Observed maize production in tonnes |

Any additional columns must be numeric. They are used as historical features,
lagged by one observation to avoid using same-season measurements to predict
that season's production. The API carries forward each county's last observed
feature values when making the next-year forecast.
Examples include `rainfall_mm`, `mean_temperature_c`, `planted_area_ha`,
`harvested_area_ha`, and `fertilizer_kg_ha`. Blank driver values are imputed
from the training data. Production values must be nonnegative and every county
must have at least one historical observation. At least three years of
historical production are needed for a time-based holdout and training. Convert
units consistently and align crop, season, and county boundaries when
combining source exports.

Train by uploading a CSV or Excel workbook to `POST /api/v1/train` as multipart
form field `file`. The service checks a latest-year holdout and returns MAE,
RMSE, and R² where calculable. The fitted model and its training history are
persisted locally at `data/maize_model.joblib` (override with `MAIZE_MODEL_PATH`).
The random forest is used for forecasts only if it beats a trailing
three-observation-mean baseline on both MAE and RMSE in that holdout; otherwise
the system uses the baseline. This protects the forecast from a more complex
model that tests worse on the available history.

### Maize production workbook

The supplied `Maize-Production-2012-2020-Combined.xlsx` is supported directly.
The loader uses the tidy county/year/indicator/value sheet, recognizes area,
production, and yield indicators, and normalizes spelling/formatting variants
in county names. It includes 47 counties and observations for 2012–2018 and
2020; 2019 is absent. The model uses lagged production and lagged area/yield,
and does not fill or invent a 2019 observation. With this file, the latest
historical year is 2020, so its one-step-ahead forecast is for 2021—not a
current 2026 estimate. More recent observed data is necessary for current
forecasts.

## Forecast

Check `GET /api/v1/model/status` for the latest historical year and required
training features. Then call `POST /api/v1/predict` with the next year and
exactly one county entry per county:

```json
{
  "year": 2024,
  "scenarios": [
    {
      "county": "Mombasa"
    }
  ]
}
```

The example shows one scenario only; a valid request must include all 47
counties. Forecasts are limited to one season beyond the latest data because
future production lags are not observed. Each county also needs an observed
production value in the latest historical year; the service refuses to
silently use stale county history.

Reported ranges use random-forest tree spread when that model is selected, or
the 95th percentile of absolute holdout errors when the baseline is selected.
Neither is a calibrated confidence interval. Forecast quality depends on the
coverage, accuracy, and consistent definitions of source data. The supplied
workbook ends in 2020; its next-year forecast is for 2021 and must not be used
as a current estimate.

## Tests

```powershell
python -m pip install -r requirements.txt
python -m pip install pytest
python -m pytest
```

## Deployment

The root `render.yaml` deploys the Dash dashboard and FastAPI service together
as one Python web service. Upload the deployment archive and Blueprint to the
GitHub repository, then use Render's **New + → Blueprint** flow and select
that repository. The Blueprint generates the `MAIZE_ADMIN_TOKEN` as a secret.
Use the token from the service's environment settings when uploading the Excel
workbook:

```powershell
curl.exe -H "Authorization: Bearer $env:MAIZE_ADMIN_TOKEN" `
  -F "file=@C:\path\to\maize-workbook.xlsx" `
  https://YOUR-SERVICE.onrender.com/api/v1/train
```

Open the dashboard at the service root (`/`) and the API documentation at
`/docs`. The free Render service has ephemeral storage: a trained model is lost
when the service restarts or redeploys and must be uploaded again. Persistent
model storage requires a paid Render plan with a disk. The workbook currently
ends in 2020, so its forecast is for 2021 and is not a current production
estimate.
